
## Steps
0. instal virtualenv
`pip3 install virtualenv`

1. Create virtual enviroment 
`virtualenv env`

2. Activate virutal enviroment
`source env/bin/activate`

Intall flask // only once
`pip install flask`

Export Flask // only once
`export FLASK_APP=app.py`

run // turns on server
`flask run`

allow xcode to use local server
get in info.list
add AllowArbitaryLoads : Yes
inside AppTransportSecurity


Deactivate virtual enviroment
`deactivate`